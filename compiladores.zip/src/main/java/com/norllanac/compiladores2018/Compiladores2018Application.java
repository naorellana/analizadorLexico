package com.norllanac.compiladores2018;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Compiladores2018Application {

	public static void main(String[] args) {
		SpringApplication.run(Compiladores2018Application.class, args);
	}
}
